let handler = async (m, { conn, text, usedPrefix, command, args }) => {
}
handler.alias = ['tiktok', 'tikdl', 'tiktokdl', 'tiktoknowm', 'menu', 'menj', 'tu madre es puta', 'random', 'play', 'registrar', 'sticker', 'top', 'hide']
export default handler
